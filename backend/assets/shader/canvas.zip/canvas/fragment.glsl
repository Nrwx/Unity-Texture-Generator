#header
// canvas_fragment.glsl
in vec2 vUV;
in vec4 vMeta;
in vec4 vColor;
in float vRotation;

out vec4 fragColor;

uniform sampler2DArray uTexArray; // Instanced texture array
uniform sampler2D uNormal;
uniform sampler2D uDiffuse;
uniform sampler2D uBlendTex;      // Optional blend texture
uniform float uOpacity;
uniform int uBlendMode;           // Modular blending
uniform float uTime;
#endheader

// ---------------------------
// FX Helpers
// ---------------------------
vec2 rotateUV(vec2 uv, float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat2(c, -s, s, c) * (uv - 0.5) + 0.5;
}

vec2 extrudeUV(vec2 uv, float strength) {
    float h = texture(uNormal, uv).r;
    return uv + (h - 0.5) * strength;
}

vec2 invertExtrudeUV(vec2 uv, float strength) {
    float h = texture(uNormal, uv).r;
    return uv - (h - 0.5) * strength;
}

vec2 liquifyUV(vec2 uv, float time) {
    return uv + 0.02 * vec2(sin(uv.y*10.0 + time), cos(uv.x*10.0 + time));
}

vec2 cloudPatternUV(vec2 uv, float time) {
    float n = texture(uDiffuse, uv*3.0 + time*0.05).r;
    return uv + vec2(n*0.03);
}

// ---------------------------
// Main
// ---------------------------
void main() {
    vec2 uv = vUV;

    // Transform / FX
    uv = rotateUV(uv, vRotation);
    uv = extrudeUV(uv, 0.05);
    uv = invertExtrudeUV(uv, 0.02);
    uv = liquifyUV(uv, uTime);
    uv = cloudPatternUV(uv, uTime);

    // Texture Array Sampling
    vec4 color = vec4(0.0);
    int layer = int(vMeta.x + 0.5); // texture index from vMeta.x
    for(int i=0; i<MAX_SAMPLES; i++){
        float offset = float(i)/float(MAX_SAMPLES)*0.002;
        vec3 sampleUV = vec3(uv + vec2(offset), float(layer));
        color += texture(uTexArray, sampleUV);
    }
    color /= float(MAX_SAMPLES);

    // Gradient & per-instance color
    vec3 gradient = mix(vec3(1.0,0.5,0.2), vec3(0.2,0.5,1.0), uv.y);
    color.rgb *= gradient * vColor.rgb;
    color.a *= vColor.a * uOpacity;

    // Hinweis: **kein eigenes blenden mehr**, wird durch anschließenden modularen Blend-Shader gemacht
    fragColor = color;
}
