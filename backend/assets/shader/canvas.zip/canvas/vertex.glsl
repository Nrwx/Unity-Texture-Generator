#header
// canvas_vertex.glsl
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec2 aUV;
layout(location = 2) in vec4 aMeta;   // x = texture layer, yzw = custom
layout(location = 3) in vec4 aColor;
layout(location = 4) in float aRotation;

out vec2 vUV;
out vec4 vMeta;
out vec4 vColor;
out float vRotation;
#endheader

void main() {
    vUV = aUV;
    vMeta = aMeta;
    vColor = aColor;
    vRotation = aRotation;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
