#fragment
vec3 blendLuminosity(vec3 b, vec3 s);
#endfragment