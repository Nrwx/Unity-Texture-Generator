#fragment
vec3 blendColor(vec3 b, vec3 s);
#endfragment