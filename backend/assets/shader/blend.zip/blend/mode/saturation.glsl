#fragment
vec3 blendSaturation(vec3 b, vec3 s);
#endfragment