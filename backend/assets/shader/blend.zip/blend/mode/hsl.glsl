#fragment
vec3 rgb2hsl(vec3 c) {
    float maxc = max(max(c.r, c.g), c.b);
    float minc = min(min(c.r, c.g), c.b);
    float l = (maxc + minc) * 0.5;

    float s = 0.0;
    float h = 0.0;

    if (maxc != minc) {
        float d = maxc - minc;
        s = (l > 0.5) ? d / (2.0 - maxc - minc) : d / (maxc + minc);

        if (maxc == c.r) {
            h = (c.g - c.b) / d + (c.g < c.b ? 6.0 : 0.0);
        } else if (maxc == c.g) {
            h = (c.b - c.r) / d + 2.0;
        } else {
            h = (c.r - c.g) / d + 4.0;
        }

        h /= 6.0;
    }

    return vec3(h, s, l);
}


vec3 hsl2rgb(vec3 hsl) {
    float h = hsl.x;
    float s = hsl.y;
    float l = hsl.z;

    float c = (1.0 - abs(2.0 * l - 1.0)) * s;
    float x = c * (1.0 - abs(mod(h * 6.0, 2.0) - 1.0));
    float m = l - c * 0.5;

    vec3 rgb;

    if (h < 1.0/6.0)      rgb = vec3(c, x, 0.0);
    else if (h < 2.0/6.0) rgb = vec3(x, c, 0.0);
    else if (h < 3.0/6.0) rgb = vec3(0.0, c, x);
    else if (h < 4.0/6.0) rgb = vec3(0.0, x, c);
    else if (h < 5.0/6.0) rgb = vec3(x, 0.0, c);
    else                  rgb = vec3(c, 0.0, x);

    return rgb + m;
}

vec3 setHue(vec3 base, vec3 blend) {
    vec3 b = rgb2hsl(base);
    vec3 s = rgb2hsl(blend);
    return hsl2rgb(vec3(s.x, b.y, b.z));
}

vec3 setSaturation(vec3 base, vec3 blend) {
    vec3 b = rgb2hsl(base);
    vec3 s = rgb2hsl(blend);
    return hsl2rgb(vec3(b.x, s.y, b.z));
}

vec3 setColor(vec3 base, vec3 blend) {
    vec3 b = rgb2hsl(base);
    vec3 s = rgb2hsl(blend);
    return hsl2rgb(vec3(s.x, s.y, b.z));
}

vec3 setLuminosity(vec3 base, vec3 blend) {
    vec3 b = rgb2hsl(base);
    vec3 s = rgb2hsl(blend);
    return hsl2rgb(vec3(b.x, b.y, s.z));
}
#endfragment