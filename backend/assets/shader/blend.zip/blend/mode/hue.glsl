#fragment
vec3 blendHue(vec3 b, vec3 s);
#endfragment