#header
in vec2 vUV;
out vec4 fragColor;

uniform sampler2D uBaseColor;   // z.B. Scene Color
uniform sampler2D uBlendColor;  // z.B. Overlay
uniform int uBlendMode;
#endheader

void main() {
    vec4 base  = texture(uBaseColor, vUV);
    vec4 blend = texture(uBlendColor, vUV);

    fragColor = blendMode(base, blend, uBlendMode);
}
