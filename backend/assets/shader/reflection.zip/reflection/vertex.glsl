#header
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;

layout(location = 4) in vec4  aBoneWeights;
layout(location = 5) in ivec4 aBoneIndices;

layout(location = 6) in mat4 iModelMatrix;

uniform mat4 uViewProj;
uniform mat4 uBones[128];

out vec3 vWorldPos;
out vec3 vWorldNormal;
#endheader

void main() {
    mat4 skin = getSkinMatrix();

    vec4 skinnedPos    = skin * vec4(aPos, 1.0);
    vec3 skinnedNormal = mat3(skin) * aNormal;

    vec4 worldPos = iModelMatrix * skinnedPos;

    vWorldPos    = worldPos.xyz;
    vWorldNormal = normalize(mat3(iModelMatrix) * skinnedNormal);

    gl_Position = uViewProj * worldPos;
}
