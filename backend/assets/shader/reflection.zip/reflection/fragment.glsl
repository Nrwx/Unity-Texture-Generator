#header
in vec3 vWorldPos;
in vec3 vWorldNormal;

out vec4 fragColor;
uniform samplerCube uReflectionMap;

uniform vec3 uCameraPos;

uniform float uReflectionFactor;
uniform float uRoughness;
uniform float uMetallic;

uniform float uFresnelPower;
uniform float uFresnelStrength;

uniform float uMaxReflectionLOD;

uniform vec3 uEnvBoxMin;
uniform vec3 uEnvBoxMax;
uniform vec3 uEnvBoxCenter;
#endheader

void main() {
    if (uReflectionFactor <= 0.001) {
        discard;
    }

    vec3 N = normalize(vWorldNormal);
    vec3 V = normalize(uCameraPos - vWorldPos);

    // Reflection direction
    vec3 R = reflect(-V, N);

    // Box projected cubemap
    vec3 Rbox = boxProject(R, vWorldPos);

    // Roughness → LOD
    float lod = clamp(uRoughness * uMaxReflectionLOD, 0.0, uMaxReflectionLOD);

    vec3 env = textureLod(uReflectionMap, Rbox, lod).rgb;

    // Fresnel
    float fresnel = pow(1.0 - max(dot(N, V), 0.0), uFresnelPower);
    fresnel = mix(1.0, fresnel, uFresnelStrength);

    // Metallic weighting
    float reflectivity = mix(0.04, 1.0, uMetallic);

    float strength =
        uReflectionFactor *
        reflectivity *
        fresnel;

    strength = clamp(strength, 0.0, 1.0);

    fragColor = vec4(env, strength);
}
