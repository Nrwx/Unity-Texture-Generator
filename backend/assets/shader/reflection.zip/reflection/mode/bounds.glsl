#fragment
vec3 boxProject(vec3 R, vec3 worldPos) {
    vec3 rbmax = (uEnvBoxMax - worldPos) / R;
    vec3 rbmin = (uEnvBoxMin - worldPos) / R;

    vec3 rbminmax;
    rbminmax.x = (R.x > 0.0) ? rbmax.x : rbmin.x;
    rbminmax.y = (R.y > 0.0) ? rbmax.y : rbmin.y;
    rbminmax.z = (R.z > 0.0) ? rbmax.z : rbmin.z;

    float dist = min(min(rbminmax.x, rbminmax.y), rbminmax.z);
    vec3 hitPos = worldPos + R * dist;

    return normalize(hitPos - uEnvBoxCenter);
}
#endfragment