#header
in vec2 vUV;
in vec3 vWorldPos;
in vec3 vNormal;
flat in float vTexIndex;
flat in vec4 vInstanceColor;

out vec4 fragColor;

uniform sampler2D uDetail;
uniform sampler2D uDetailNormal;
uniform sampler2DArray uDetailArray;

uniform sampler2D uAmbientOcclusion;
uniform sampler2DArray uAmbientOcclusionArray;
uniform float uAmbientOcclusionFactor;
uniform int uUseAmbientOcclusionMap;

// Flags / params
uniform int uUseTextureArray;
uniform int uUseDetail;
uniform int uUseDetailModulateByAO;
uniform float uDetailFactor;
uniform float uDetailScale;
uniform int uDetailMode;

// LOD
#define MAX_LOD_LEVELS 8
uniform int uUseLOD;
uniform int uLODCount;
uniform float uLODDistances[MAX_LOD_LEVELS];
uniform float uLODFade;
uniform float uLODBias;

uniform vec3 uCameraPos;
#endheader

void main() {
    if (uUseDetail == 0 || uDetailFactor <= 0.0) {
        discard;
    }

    float lodFactor = getLodFactorFromPos(vWorldPos);

    vec3 detail = sampleDetail(vUV, lodFactor);
    float ao = sampleAO(vUV);

    vec3 baseColor = vInstanceColor.rgb;
    vec3 outColor = applyDetail(baseColor, detail, ao, lodFactor, vUV);

    fragColor = vec4(outColor, clamp(uDetailFactor, 0.0, 1.0));
}