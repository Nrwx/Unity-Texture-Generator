#header
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aUV;
layout(location = 4) in vec4 aBoneWeights;
layout(location = 5) in ivec4 aBoneIndices;

// instancing
layout(location = 6) in mat4 iModelMatrix;
layout(location = 10) in vec4 iUVTransform; // x,y = offset, z,w = scale
layout(location = 11) in vec4 iColor;
layout(location = 12) in float iTexIndex; // texture array layer per-instance

uniform mat4 uViewProj;
uniform mat4 uBones[128];

out vec2 vUV;
out vec3 vWorldPos;
out vec3 vNormal;
flat out float vTexIndex;
flat out vec4 vInstanceColor;
#endheader

void main() {
    mat4 skin = getSkinMatrix();

    vec4 skinnedPos = skin * vec4(aPos, 1.0);
    vec3 skinnedNormal = mat3(skin) * aNormal;

    vec4 worldPos = iModelMatrix * skinnedPos;

    vUV = transformUV(aUV, iUVTransform.xy, iUVTransform.zw);
    vWorldPos = worldPos.xyz;
    vNormal = normalize(mat3(iModelMatrix) * skinnedNormal);
    vTexIndex = iTexIndex;
    vInstanceColor = iColor;

    gl_Position = uViewProj * worldPos;
}
