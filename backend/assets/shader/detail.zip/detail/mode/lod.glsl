#fragment
// lod.glsl

// get integer LOD level from distance (0..uLODCount)
// returns value clamped to [0, uLODCount]
int getLodLevelFromDistance(float d) {
    int lvl = 0;
    for (int i = 0; i < MAX_LOD_LEVELS; ++i) {
        if (i >= uLODCount) break;
        if (d > uLODDistances[i]) lvl = i + 1;
    }
    return lvl;
}

// compute a smooth blend factor [0..1] for how much "far" LOD should influence
// when inside fade region around a threshold we smoothly interpolate.
// returns value where 0 = fully near (use high-detail), 1 = fully far (low-detail)
float computeLodBlend(float d) {
    if (uUseLOD == 0 || uLODCount == 0) return 0.0;
    // find threshold just greater than d
    for (int i = 0; i < MAX_LOD_LEVELS; ++i) {
        if (i >= uLODCount) break;
        float thresh = uLODDistances[i];
        float prev = (i == 0) ? 0.0 : uLODDistances[i - 1];
        // If d <= thresh: compute normalized position between prev and thresh
        if (d <= thresh) {
            float span = max(0.0001, thresh - prev);
            float local = clamp((d - prev) / span, 0.0, 1.0);
            // Optionally apply fade width (uLODFade) centered on each threshold:
            // compute blend around thresh with uLODFade
            float fade = clamp(uLODFade, 0.0001, span);
            // if close to previous threshold -> near, else blend toward this threshold
            float edgeLow = thresh - fade * 0.5;
            float edgeHigh = thresh + fade * 0.5;
            // Smoothstep between edgeLow..edgeHigh
            return clamp(smoothstep(edgeLow, edgeHigh, d), 0.0, 1.0);
        }
    }
    // beyond last threshold -> full far
    return 1.0;
}

// compute LOD factor used to scale sampling LOD (0 = high detail, 1 = low detail)
// maps world-distance -> [0..1]
float getLodFactorFromPos(vec3 worldPos) {
    if (uUseLOD == 0) return 0.0;
    float d = length(uCameraPos - worldPos);
    return computeLodBlend(d);
}

// LOD-aware sampling for detail map (returns sampled color)
// uses textureLod (if available) to pick mip-level according to lodFactor and uLODBias
vec3 sampleDetailWithLod(
    sampler2D map,
    vec2 uv,
    float scale,
    float lodFactor
) {
    vec2 uvScaled = uv * scale;

    if (uUseLOD == 1) {
        float lod = lodFactor * uLODBias;
        return textureLod(map, uvScaled, lod).rgb;
    }

    return texture(map, uvScaled).rgb;
}

// Combined helper: returns detail contribution 0..1 (multiplied by uDetailFactor in higher level)
vec3 getDetailColorLOD(vec2 uv, vec3 baseColor, vec3 worldPos, float baseScale) {
    float lodFactor = getLodFactorFromPos(worldPos); // 0..1
    vec3 detail = sampleDetailWithLod(uDetail, uv, baseScale, lodFactor);
    // blend depending on lodFactor (near -> full detail, far -> none)
    float nearWeight = 1.0 - lodFactor;
    // combine multiplicatively and mix
    vec3 mixed = baseColor * detail;
    return mix(baseColor, mixed, clamp(uDetailFactor * nearWeight, 0.0, 1.0));
}
#endfragment
