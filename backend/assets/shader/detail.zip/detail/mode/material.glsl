#fragment
vec3 sampleDetailSampler2D(vec2 uv, float lodFactor) {
    vec2 uvScaled = uv * uDetailScale;

    if (uUseLOD == 1) {
        float lod = lodFactor * uLODBias;
        return textureLod(uDetail, uvScaled, lod).rgb;
    }

    return texture(uDetail, uvScaled).rgb;
}

vec3 sampleDetailSamplerArray(vec2 uv) {
    int layer = int(max(0.0, vTexIndex));
    vec2 uvScaled = uv * uDetailScale;

    return texture(uDetailArray, vec3(uvScaled, float(layer))).rgb;
}

vec3 sampleDetail(vec2 uv, float lodFactor) {
    if (uUseTextureArray == 1) {
        return sampleDetailSamplerArray(uv);
    }
    return sampleDetailSampler2D(uv, lodFactor);
}

float sampleAO(vec2 uv) {
    if (uUseAmbientOcclusionMap == 0) {
        return clamp(uAmbientOcclusionFactor, 0.0, 1.0);
    }

    if (uUseTextureArray == 1) {
        int layer = int(max(0.0, vTexIndex));
        return texture(uAmbientOcclusionArray, vec3(uv, float(layer))).r;
    }

    return texture(uAmbientOcclusion, uv).r;
}

// Detail map overlay, optional modulation by AO
vec3 applyDetail(vec3 baseColor, vec3 detailColor, float ao, float lodFactor, vec2 uv) {
    if(uUseDetail == 0) return baseColor;

    float scale = (uDetailScale > 0.0) ? uDetailScale : 4.0;
    vec2 detailUV = uv * scale;

    // Detailmap abtasten
    vec3 detail = texture(uDetail, detailUV).rgb;

    // Multipliziere Basisfarbe mit Detail
    vec3 mixed = baseColor * detail;

    // AO-Modulation optional
    if(uUseDetailModulateByAO == 1) mixed *= ao;

    // Blende zwischen Basisfarbe und Detail
    return mix(baseColor, mixed, clamp(uDetailFactor, 0.0, 1.0));
}


#endfragment