#vertex
vec2 transformUV(vec2 uv, vec2 offset, vec2 scale) {
    return uv * scale + offset;
}
#endvertex