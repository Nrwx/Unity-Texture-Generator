#header
attribute vec2 a_position;
#endheader

void main() {
    gl_Position = vec4(a_position, 0.0, 1.0);
}