#header
in vec2 vUV;
out vec4 fragColor;

uniform sampler2D uSceneColor;
uniform sampler2D uDepth;

uniform mat4  uInvViewProj;
uniform vec3  uCameraPos;
uniform float uNear;
uniform float uFar;

// core fog params
uniform int   uFogEnabled;
uniform vec3  uFogColor;
uniform float uFogDensity;
uniform float uFogRange;
uniform float uFogBaseHeight;
uniform float uFogHeightFalloff;
uniform int   uFogMode; // 0 = exp2, 1 = linear

#ifdef FOG_NOISE
uniform sampler2D uFogNoise;
uniform float uFogNoiseScale;
uniform float uFogNoiseStrength;
#endif

#ifdef FOG_SUN
uniform vec3 uFogSunDir;
uniform float uFogSunStrength;
#endif

#ifdef FOG_ANISOTROPY
uniform float uFogAnisotropy;
uniform vec3  uFogLightDir;
#endif

#ifdef FOG_GROUND
uniform float uFogGroundHeight;
uniform float uFogGroundSoftness;
#endif

#ifdef FOG_CAMERA_FADE
uniform float uFogNearFade;
#endif

// Helper: linearize depth
float linearizeDepth(float depth) {
    float z = depth * 2.0 - 1.0;
    return (2.0 * uNear * uFar) / (uFar + uNear - z * (uFar - uNear));
}

vec3 reconstructWorldPos(vec2 uv, float depth) {
    float z = depth * 2.0 - 1.0;
    vec4 clip = vec4(uv * 2.0 - 1.0, z, 1.0);
    vec4 world = uInvViewProj * clip;
    return world.xyz / world.w;
}
#endheader

void main() {
    vec4 sceneColor = texture(uSceneColor, vUV);

    if (uFogEnabled == 0) {
        fragColor = sceneColor;
        return;
    }

    float depth = texture(uDepth, vUV).r;

    if (depth >= 1.0) {
        fragColor = sceneColor;
        return;
    }

    vec3 worldPos = reconstructWorldPos(vUV, depth);
    float dist = length(worldPos - uCameraPos);
    vec3 viewDir = normalize(uCameraPos - worldPos);

    // base fog factor
    float fogFactor = 0.0;
    if (uFogMode == 1) {
        fogFactor = clamp(dist / max(0.0001, uFogRange), 0.0, 1.0);
    } else {
        float d = dist * uFogDensity;
        fogFactor = 1.0 - exp(-d * d);
    }

    // height attenuation
    float heightAtten = exp(-(worldPos.y - uFogBaseHeight) * uFogHeightFalloff);
    heightAtten = clamp(heightAtten, 0.0, 1.0);
    fogFactor *= heightAtten;

    // optional modules (guarded by defines)
    #ifdef FOG_CAMERA_FADE
        fogFactor = applyCameraFade(dist, fogFactor);
    #endif

    #ifdef FOG_GROUND
        fogFactor = applyGroundFog(worldPos, fogFactor);
    #endif

    #ifdef FOG_NOISE
        fogFactor = applyFogNoise(worldPos, fogFactor);
    #endif

    #ifdef FOG_SUN
        fogFactor = applySunFog(viewDir, fogFactor);
    #endif

    #ifdef FOG_ANISOTROPY
        fogFactor = applyAnisotropy(viewDir, uFogLightDir, fogFactor);
    #endif

    fogFactor = clamp(fogFactor, 0.0, 1.0);
    vec3 finalCol = mix(sceneColor.rgb, uFogColor, fogFactor);
    fragColor = vec4(finalCol, sceneColor.a);
}
