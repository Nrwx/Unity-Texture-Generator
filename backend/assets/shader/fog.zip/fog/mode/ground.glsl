#fragment
// ground.glsl
// Requires: float uFogGroundHeight; float uFogGroundSoftness;
float applyGroundFog(vec3 worldPos, float fogFactor) {
    float h = smoothstep(uFogGroundHeight + uFogGroundSoftness, uFogGroundHeight, worldPos.y);
    return fogFactor * h;
}
#endfragment
