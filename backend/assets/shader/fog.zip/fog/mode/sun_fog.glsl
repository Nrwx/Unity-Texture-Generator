#fragment
// sun_fog.glsl
// Requires: vec3 uFogSunDir; float uFogSunStrength;
float applySunFog(vec3 viewDir, float fogFactor) {
    float sunAmount = max(dot(viewDir, -normalize(uFogSunDir)), 0.0);
    return fogFactor + sunAmount * uFogSunStrength * fogFactor;
}
#endfragment
