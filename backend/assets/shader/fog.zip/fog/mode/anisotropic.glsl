#fragment
// anisotropic.glsl
// Requires: float uFogAnisotropy; vec3 uFogLightDir (optional)
float applyAnisotropy(vec3 viewDir, vec3 lightDir, float fogFactor) {
    float g = clamp(uFogAnisotropy, -0.99, 0.99);
    float cosTheta = dot(viewDir, normalize(lightDir));
    float denom = 1.0 + g * g - 2.0 * g * cosTheta;
    float phase = (1.0 - g * g) / pow(denom, 1.5);
    // phase is not normalized to [0,1] — multiply with fogFactor and small scale
    return fogFactor * (phase * 0.5);
}
#endfragment
