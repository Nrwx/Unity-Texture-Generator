#fragment
// camera_fade.glsl
// Requires: float uFogNearFade;
float applyCameraFade(float distance, float fogFactor) {
    float fade = smoothstep(0.0, uFogNearFade, distance);
    return fogFactor * fade;
}
#endfragment
