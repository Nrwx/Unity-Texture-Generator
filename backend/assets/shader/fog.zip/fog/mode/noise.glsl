#fragment
// noise.glsl
// Requires: sampler2D uFogNoise; float uFogNoiseScale; float uFogNoiseStrength;
float applyFogNoise(vec3 worldPos, float fogFactor) {
    vec2 uv = worldPos.xz * uFogNoiseScale;
    // Use fract + wrap for tiling noise or assume noise is tiled
    float n = texture(uFogNoise, fract(uv)).r;
    return clamp(fogFactor + (n - 0.5) * uFogNoiseStrength, 0.0, 1.0);
}
#endfragment
