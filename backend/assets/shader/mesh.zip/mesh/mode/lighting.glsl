#fragment
// lighting.glsl
// Simple lighting: Lambert diffuse + Blinn-Phong specular using specular map and roughness
vec3 calcSpecular(vec3 N, vec3 L, vec3 V, float roughness, vec3 specColor) {
    vec3 H = normalize(L + V);
    float NdotH = max(dot(N, H), 0.0);
    float shin = max(2.0, (1.0 - roughness) * 64.0);
    float spec = pow(NdotH, shin);
    return spec * specColor;
}

vec3 calcLighting(vec3 N, vec3 lightDir, vec3 baseColor) {
    vec3 V = normalize(-vWorldPos);
    float NdotL = max(dot(N, lightDir), 0.0);
    vec3 diffuse = baseColor * NdotL;

    vec3 specColor = texture(uSpecular, vUV).rgb;
    float roughness = texture(uRoughness, vUV).r;
    vec3 specular = calcSpecular(N, lightDir, V, roughness, specColor);

    return diffuse + specular;
}

float DistributionGGX(vec3 N, vec3 H, float roughness){
    float a=roughness*roughness;
    float a2=a*a;
    float NdotH=max(dot(N,H),0.0);
    float NdotH2=NdotH*NdotH;
    float denom=(NdotH2*(a2-1.0)+1.0);
    return a2/(3.14159265*denom*denom);
}

float GeometrySchlickGGX(float NdotV,float roughness){
    float r=(roughness+1.0);
    float k=(r*r)/8.0;
    return NdotV/(NdotV*(1.0-k)+k);
}

float GeometrySmith(vec3 N, vec3 V, vec3 L, float roughness){
    float NdotV=max(dot(N,V),0.0);
    float NdotL=max(dot(N,L),0.0);
    float ggx2=GeometrySchlickGGX(NdotV,roughness);
    float ggx1=GeometrySchlickGGX(NdotL,roughness);
    return ggx1*ggx2;
}

vec3 fresnelSchlick(float cosTheta, vec3 F0){
    return F0 + (1.0-F0)*pow(1.0-cosTheta,5.0);
}

// PBR Lighting Module
vec3 computeSunLight(vec3 N, vec3 V, vec3 albedo, float metallic, float roughness, vec3 lightDir, vec3 lightColor, float intensity, float shadow) {
    vec3 L = normalize(-lightDir);
    vec3 H = normalize(V + L);
    float NdotL = max(dot(N, L), 0.0);
    if (NdotL <= 0.0) return vec3(0.0);

    vec3 F0 = mix(vec3(0.04), albedo, metallic);
    float D = DistributionGGX(N, H, roughness);
    float G = GeometrySmith(N, V, L, roughness);
    vec3 F = fresnelSchlick(max(dot(H, V), 0.0), F0);
    vec3 spec = (D * G * F) / max(4.0 * max(dot(N, V), 0.001) * NdotL, 0.0001);
    vec3 kS = F;
    vec3 kD = (1.0 - kS) * (1.0 - metallic);

    return (kD * albedo / 3.14159265 + spec) * lightColor * intensity * shadow * NdotL;
}

vec3 computePointLight(vec3 N, vec3 V, vec3 albedo, float metallic, float roughness, vec3 lightPos, vec3 lightColor, float intensity, float range, vec3 fragPos) {
    vec3 L = normalize(lightPos - fragPos);
    float distance = length(lightPos - fragPos);
    if(distance > range) return vec3(0.0);

    float attenuation = pow(clamp(1.0 - distance / range, 0.0, 1.0), 2.0); // simple decay
    float NdotL = max(dot(N, L), 0.0);
    if(NdotL <= 0.0) return vec3(0.0);

    vec3 H = normalize(V + L);
    vec3 F0 = mix(vec3(0.04), albedo, metallic);
    float D = DistributionGGX(N, H, roughness);
    float G = GeometrySmith(N, V, L, roughness);
    vec3 F = fresnelSchlick(max(dot(H, V), 0.0), F0);
    vec3 spec = (D * G * F) / max(4.0 * max(dot(N, V), 0.001) * NdotL, 0.0001);
    vec3 kS = F;
    vec3 kD = (1.0 - kS) * (1.0 - metallic);

    return (kD * albedo / 3.14159265 + spec) * lightColor * intensity * attenuation * NdotL;
}

vec3 computeSpotLight(vec3 N, vec3 V, vec3 albedo, float metallic, float roughness, vec3 lightPos, vec3 lightDir, float innerCos, float outerCos, vec3 lightColor, float intensity, float range, vec3 fragPos) {
    vec3 L = normalize(lightPos - fragPos);
    float distance = length(lightPos - fragPos);
    if(distance > range) return vec3(0.0);

    float spotFactor = 1.0;
    if(outerCos > -0.5){
        float cosAngle = dot(L, normalize(-lightDir));
        spotFactor = smoothstep(outerCos, innerCos, cosAngle);
    }

    float attenuation = pow(clamp(1.0 - distance / range, 0.0, 1.0), 2.0) * spotFactor;
    float NdotL = max(dot(N, L), 0.0);
    if(NdotL <= 0.0) return vec3(0.0);

    vec3 H = normalize(V + L);
    vec3 F0 = mix(vec3(0.04), albedo, metallic);
    float D = DistributionGGX(N, H, roughness);
    float G = GeometrySmith(N, V, L, roughness);
    vec3 F = fresnelSchlick(max(dot(H, V), 0.0), F0);
    vec3 spec = (D * G * F) / max(4.0 * max(dot(N, V), 0.001) * NdotL, 0.0001);
    vec3 kS = F;
    vec3 kD = (1.0 - kS) * (1.0 - metallic);

    return (kD * albedo / 3.14159265 + spec) * lightColor * intensity * attenuation * NdotL;
}

// Ambient Light
vec3 computeAmbientLight(vec3 albedo, float ao, vec3 ambientColor, float ambientIntensity) {
    return albedo * ao * ambientColor * ambientIntensity;
}

// Rect Light (basic PBR approximation)
vec3 computeRectLight(vec3 N, vec3 V, vec3 albedo, float metallic, float roughness,
                      vec3 rectPos, vec3 rectNormal, vec3 lightColor, float intensity,
                      vec2 size, vec3 fragPos) {
    // simple approximation: point-like center with normal falloff
    vec3 L = rectPos - fragPos;
    float distance = length(L);
    L = normalize(L);
    float NdotL = max(dot(N, L), 0.0);
    float rectFalloff = max(dot(-L, rectNormal), 0.0); // face orientation
    float attenuation = pow(clamp(1.0 - distance / max(size.x, size.y), 0.0, 1.0), 2.0) * rectFalloff;
    if(NdotL <= 0.0 || attenuation <= 0.0) return vec3(0.0);

    vec3 H = normalize(V + L);
    vec3 F0 = mix(vec3(0.04), albedo, metallic);
    float D = DistributionGGX(N, H, roughness);
    float G = GeometrySmith(N, V, L, roughness);
    vec3 F = fresnelSchlick(max(dot(H, V), 0.0), F0);
    vec3 spec = (D * G * F) / max(4.0 * max(dot(N, V), 0.001) * NdotL, 0.0001);
    vec3 kS = F;
    vec3 kD = (1.0 - kS) * (1.0 - metallic);

    return (kD * albedo / 3.14159265 + spec) * lightColor * intensity * attenuation * NdotL;
}

vec3 computeAllPointLights(vec3 N, vec3 V, vec3 albedo, float metallic, float roughness,
                           int count, vec4 positions[MAX_POINT_LIGHTS],
                           vec4 colors[MAX_POINT_LIGHTS],
                           vec4 dirs[MAX_POINT_LIGHTS],
                           vec4 params[MAX_POINT_LIGHTS],
                           vec3 fragPos) {
    vec3 result = vec3(0.0);
    for(int i=0; i<count; i++){
        result += computePointLight(N, V, albedo, metallic, roughness,
                                    positions[i].xyz,
                                    colors[i].rgb,
                                    colors[i].a,
                                    positions[i].w,
                                    fragPos);
    }
    return result;
}

#endfragment
