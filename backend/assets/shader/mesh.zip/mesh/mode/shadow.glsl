#fragment
// shadow.glsl
// Shadow helper functions (no main), for use in mesh fragment shader

// --------------------------------------------------
// simple PCF box sampling
// --------------------------------------------------
float sampleShadowPCF(
    sampler2D shadowMap,
    vec2 uv,
    float compareDepth,
    ivec2 mapSize,
    int kernel
) {
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) return 1.0;

    vec2 texel = 1.0 / vec2(mapSize);
    int k = max(1, kernel);
    float sum = 0.0;
    int count = 0;

    for (int y = -k; y <= k; ++y) {
        for (int x = -k; x <= k; ++x) {
            vec2 offs = vec2(float(x), float(y)) * texel;
            float d = texture(shadowMap, uv + offs).r;
            if (compareDepth <= d) sum += 1.0;
            count++;
        }
    }

    return sum / float(count);
}

// --------------------------------------------------
// helper: single cascade evaluation
// --------------------------------------------------
float evalCascade(
    vec3 worldPos,
    sampler2D shadowMap,
    mat4 lightVP,
    ivec2 mapSize,
    float bias,
    int kernel
) {
    vec4 lp = lightVP * vec4(worldPos, 1.0);
    if (lp.w == 0.0) return 1.0;

    vec3 proj = lp.xyz / lp.w;
    vec2 uv = proj.xy * 0.5 + 0.5;
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) return 1.0;

    float depth = proj.z * 0.5 + 0.5;
    return sampleShadowPCF(shadowMap, uv, depth - bias, mapSize, kernel);
}

// --------------------------------------------------
// Cascaded shadow mapping (directional) — FIXED
// --------------------------------------------------
float calcCSMShadow(
    vec3 worldPos,
    sampler2D uShadowMaps[NUM_CASCADES],
    mat4 uLightViewProj[NUM_CASCADES],
    int uCascadeCount,
    float uShadowBias,
    int uShadowPCFKernel,
    ivec2 uShadowMapSize[NUM_CASCADES]
) {
    float shadow = 1.0;

#if NUM_CASCADES > 0
    if (uCascadeCount > 0) {
        return evalCascade(
            worldPos,
            uShadowMaps[0],
            uLightViewProj[0],
            uShadowMapSize[0],
            uShadowBias,
            uShadowPCFKernel
        );
    }
#endif

#if NUM_CASCADES > 1
    if (uCascadeCount > 1) {
        return evalCascade(
            worldPos,
            uShadowMaps[1],
            uLightViewProj[1],
            uShadowMapSize[1],
            uShadowBias,
            uShadowPCFKernel
        );
    }
#endif

#if NUM_CASCADES > 2
    if (uCascadeCount > 2) {
        return evalCascade(
            worldPos,
            uShadowMaps[2],
            uLightViewProj[2],
            uShadowMapSize[2],
            uShadowBias,
            uShadowPCFKernel
        );
    }
#endif

#if NUM_CASCADES > 3
    if (uCascadeCount > 3) {
        return evalCascade(
            worldPos,
            uShadowMaps[3],
            uLightViewProj[3],
            uShadowMapSize[3],
            uShadowBias,
            uShadowPCFKernel
        );
    }
#endif

    return shadow;
}

// --------------------------------------------------
// Spot shadow (single map)
// --------------------------------------------------
float calcSpotShadow(
    vec3 worldPos,
    sampler2D uSpotShadowMap,
    mat4 uSpotLightVP,
    float uSpotShadowBias,
    int uShadowPCFKernel,
    int uUseSpotShadow
) {
    if (uUseSpotShadow == 0) return 1.0;

    vec4 lp = uSpotLightVP * vec4(worldPos, 1.0);
    if (lp.w == 0.0) return 1.0;

    vec3 proj = lp.xyz / lp.w;
    vec2 uv = proj.xy * 0.5 + 0.5;
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) return 1.0;

    ivec2 mapSize = ivec2(1024, 1024);
    float depth = proj.z * 0.5 + 0.5;

    return sampleShadowPCF(
        uSpotShadowMap,
        uv,
        depth - uSpotShadowBias,
        mapSize,
        uShadowPCFKernel
    );
}

// --------------------------------------------------
// optional bias helper (N·L based)
// --------------------------------------------------
float computeBias(vec3 normal, vec3 lightDir, float baseBias) {
    float ndl = max(dot(normalize(normal), normalize(-lightDir)), 0.0);
    return max(baseBias * (1.0 - ndl), baseBias * 0.25);
}
#endfragment
