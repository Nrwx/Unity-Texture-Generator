#fragment
// material.functions.glsl
// Sampling helpers and material modifiers

// --- Diffuse / Normal / PBR sampling ---
vec4 sampleDiffuse(vec2 uv, float vTexIndex, int uUseTextureArray) {
    if (uUseTextureArray == 1) {
        float layer = max(0.0, vTexIndex);
        return texture(uDiffuseArray, vec3(uv, layer));
    } else {
        return texture(uDiffuse, uv);
    }
}

vec3 sampleNormalMap(vec2 uv, float vTexIndex, int uUseTextureArray) {
    if (uUseTextureArray == 1 && uUseNormalMap == 1) {
        float layer = max(0.0, vTexIndex);
        return texture(uDiffuseArray, vec3(uv, layer)).rgb;
    } else if (uUseNormalMap == 1) {
        return texture(uNormal, uv).rgb;
    }
    return vec3(0.5, 0.5, 1.0);
}

float sampleSpecularMap(vec2 uv, float vTexIndex, int uUseTextureArray) {
    if (uUseTextureArray == 1 && uUseSpecularMap == 1) {
        float layer = max(0.0, vTexIndex);
        return texture(uDiffuseArray, vec3(uv, layer)).r;
    } else if (uUseSpecularMap == 1) {
        return texture(uSpecular, uv).r;
    }
    return 1.0;
}

float sampleSpecular(vec2 uv, float vTexIndex, int uUseTextureArray) {
    float mapVal = sampleSpecularMap(uv, vTexIndex, uUseTextureArray);
    if(uUseSpecularMap == 1 && uUseTextureArray == 0){
        return mapVal * clamp(uSpecularFactor, 0.0, 1.0);
    } else {
        return clamp(uSpecularFactor, 0.0, 1.0);
    }
}

float sampleRoughnessMap(vec2 uv, float vTexIndex, int uUseTextureArray) {
    if (uUseTextureArray == 1 && uUseRoughnessMap == 1) {
        float layer = max(0.0, vTexIndex);
        return texture(uDiffuseArray, vec3(uv, layer)).r;
    } else if (uUseRoughnessMap == 1) {
        return texture(uRoughness, uv).r;
    }
    return clamp(uRoughnessFactor, 0.0, 1.0);
}

float sampleMetallicMap(vec2 uv, float vTexIndex, int uUseTextureArray) {
    if (uUseTextureArray == 1 && uUseMetallicMap == 1) {
        float layer = max(0.0, vTexIndex);
        return texture(uDiffuseArray, vec3(uv, layer)).r;
    } else if (uUseMetallicMap == 1) {
        return texture(uMetallic, uv).r;
    }
    return clamp(uMetallicFactor, 0.0, 1.0);
}

float sampleAOMap(vec2 uv, float vTexIndex, int uUseTextureArray) {
    if (uUseTextureArray == 1 && uUseAmbientOcclusionMap == 1) {
        float layer = max(0.0, vTexIndex);
        return texture(uDiffuseArray, vec3(uv, layer)).r;
    } else if (uUseAmbientOcclusionMap == 1) {
        return texture(uAmbientOcclusion, uv).r;
    }
    return 1.0;
}

float sampleAlphaMap(vec2 uv, float vTexIndex, int uUseTextureArray) {
    if (uUseTextureArray == 1 && uUseAlphaMap == 1) {
        float layer = max(0.0, vTexIndex);
        return texture(uDiffuseArray, vec3(uv, layer)).r;
    } else if (uUseAlphaMap == 1) {
        return texture(uAlpha, uv).r;
    }
    return 1.0;
}


vec3 sampleLightMap(vec2 uv) {
    if (uUseLightMap == 1) {
        return texture(uLight, uv).rgb;
    }
    return vec3(1.0);
}

vec3 sampleNormal(vec2 uv, float vTexIndex, int useNormalArray) {
    vec3 baseN = vec3(0.0, 0.0, 1.0);
    vec3 nRaw = sampleNormalMap(uv, vTexIndex, useNormalArray);
    vec3 n = nRaw * 2.0 - 1.0;
    baseN = normalize(mix(vec3(0.0,0.0,1.0), n, clamp(uNormalFactor, 0.0, 1.0)));
    return baseN;
}

vec3 applyBump(vec3 N, vec3 V, vec2 uv){
    if(uUseBump == 0 || uUseBumpMap == 0 || uBumpFactor == 0.0) return N;

    float dx = 0.001;
    float dy = 0.001;

    float hC = texture(uBump, uv).r;
    float hL = texture(uBump, uv + vec2(-dx,0.0)).r;
    float hR = texture(uBump, uv + vec2( dx,0.0)).r;
    float hD = texture(uBump, uv + vec2(0.0,-dy)).r;
    float hU = texture(uBump, uv + vec2(0.0, dy)).r;

    float dhdx = ((hR - 0.5) - (hL - 0.5)) * uBumpFactor;
    float dhdy = ((hU - 0.5) - (hD - 0.5)) * uBumpFactor;

    vec3 T = normalize(vTangent);
    vec3 B = normalize(cross(N, T) * vTangentW);

    return normalize(N + dhdx * T + dhdy * B);
}

// --- Tint application ---
vec3 applyTint(vec3 color) {
    vec3 tinted = color * uTintColor;
    return mix(color, tinted, clamp(uTintFactor, 0.0, 1.0));
}

// alias for compatibility with existing main()
vec3 applyTintToAlbedo(vec3 color) {
    return applyTint(color);
}

// --- compose final material color (AO + light + modifiers) ---
vec4 getMaterialColor(vec2 uv, float vTexIndex, int uUseTextureArray) {
    vec4 diff = sampleDiffuse(uv, vTexIndex, uUseTextureArray);
    vec3 col = diff.rgb;
    col = applyTint(col);
    col *= uDiffuseFactor;
    return vec4(col, diff.a);
}
#endfragment

#vertex
// ---------------------------
// Vertex displacement by heightmap
// ---------------------------
vec3 displaceByHeightMap(vec3 pos, vec2 uv){
    if(uUseBump == 0 || uBumpFactor == 0.0) return pos;

    float h = texture(uBump, uv).r;
    h = (h - 0.5) * 2.0;
    pos.y += h * uBumpFactor;
    return pos;
}
#endvertex
