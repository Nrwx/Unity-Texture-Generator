#header
// Vertex attributes
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aUV;
layout(location = 3) in vec4 aTangent;

layout(location = 4) in vec4 aBoneWeights;
layout(location = 5) in ivec4 aBoneIndices;

// Instanced attributes
layout(location = 6) in mat4 iModelMatrix;
layout(location = 10) in vec4 iUVTransform;
layout(location = 11) in vec4 iColor;
layout(location = 12) in float iTexIndex;

// Global uniforms
uniform mat4 uViewProj;
uniform mat4 uView;
uniform mat3 uNormalMatrix;
uniform mat4 uBones[128]; // MAX_BONES

// Bump map for displacement
uniform int uUseBump;
uniform int uUseBumpMap;
uniform sampler2D uBump;
uniform float uBumpFactor;

// Vertex outputs
out vec2 vUV;
out vec3 vNormal;
out vec3 vWorldPos;
out vec3 vTangent;
out float vTangentW;
flat out vec4 vInstanceColor;
flat out float vTexIndex;
#endheader

void main() {
    // 1️⃣ Apply skinning
    vec4 skinnedPos = applySkinning(vec4(aPos, 1.0));
    vec3 skinnedNormal = mat3(getSkinMatrix()) * aNormal;
    vec3 skinnedTangent = mat3(getSkinMatrix()) * aTangent.xyz;

    // 2️⃣ UV transform
    vUV = transformUV(aUV, iUVTransform.xy, iUVTransform.zw, 0.0);

    // 3️⃣ Compute final vertex position
    vec3 finalPos = skinnedPos.xyz;

    if (uUseBump == 1) {
        finalPos = displaceByHeightMap(skinnedPos.xyz, vUV);
    }

    // 4️⃣ Compute world position
    vec4 worldPos = iModelMatrix * vec4(finalPos, 1.0);
    vWorldPos = worldPos.xyz;

    // 5️⃣ Compute normals (TBN)
    vec3 T = normalize(mat3(iModelMatrix) * skinnedTangent);
    vec3 N = normalize(mat3(iModelMatrix) * skinnedNormal);
    vec3 B = normalize(cross(N, T) * aTangent.w);

    vNormal = N;
    vTangent = T;
    vTangentW = aTangent.w;

    // 6️⃣ Instance attributes
    vInstanceColor = iColor;
    vTexIndex = iTexIndex;

    // 7️⃣ Output position
    gl_Position = uViewProj * worldPos;
}