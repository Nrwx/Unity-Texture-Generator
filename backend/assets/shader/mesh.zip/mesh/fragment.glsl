#header
in vec2 vUV;
in vec3 vNormal;
in vec3 vWorldPos;
in vec3 vTangent;
in float vTangentW;
flat in vec4 vInstanceColor;
flat in float vTexIndex;

out vec4 fragColor;

/* color tint */
uniform vec3 uTintColor;
uniform float uTintFactor;

// Material Flags
uniform int uUseNormal;
uniform int uUseNormalMap;
uniform int uUseSpecular;
uniform int uUseSpecularMap;
uniform int uUseRoughness;
uniform int uUseRoughnessMap;
uniform int uUseMetallic;
uniform int uUseMetallicMap;
uniform int uUseAmbientOcclusion;
uniform int uUseAmbientOcclusionMap;
uniform int uUseLight;
uniform int uUseLightMap;
uniform int uUseBump;
uniform int uUseBumpMap;

uniform int uUseAlpha;
uniform int uUseAlphaMap;

uniform int uUseTextureArray;
uniform int uUseNormalArray;

// Material samplers
uniform sampler2D uDiffuse;
uniform sampler2D uNormal;
uniform sampler2D uSpecular;
uniform sampler2D uRoughness;
uniform sampler2D uMetallic;
uniform sampler2D uAmbientOcclusion;
uniform sampler2D uLight;
uniform sampler2D uBump;
uniform sampler2D uAlpha;

uniform sampler2DArray uDiffuseArray;

// Material Factor
uniform float uDiffuseFactor;
uniform float uNormalFactor;
uniform float uSpecularFactor;
uniform float uRoughnessFactor;
uniform float uMetallicFactor;
uniform float uAmbientOcclusionFactor;
uniform float uLightFactor;
uniform float uBumpFactor;
uniform float uAlphaFactor;

// Material LOD
#define MAX_LOD_LEVELS 8
uniform int uUseLOD;
uniform int uLODCount;
uniform float uLODDistances[MAX_LOD_LEVELS];
uniform float uLODFade;
uniform float uLODBias;

// PBR / lighting uniforms
uniform vec3 uCameraPos;
uniform vec4 uVertexColor;
uniform float uAlphaThreshold;

// Lights
uniform int uPointCount;
uniform vec4 uPointPositions[128];
uniform vec4 uPointColors[128];
uniform vec4 uPointDirs[128];
uniform vec4 uPointParams[128];

uniform vec3 uSunDirection;
uniform vec3 uSunColor;
uniform float uSunIntensity;

uniform vec3 uAmbientColor;
uniform float uAmbientIntensity;

uniform vec3  uSpotPosition;
uniform vec3  uSpotDirection;
uniform vec3  uSpotColor;
uniform float uSpotIntensity;
uniform float uSpotRange;
uniform float uSpotInnerCos;
uniform float uSpotOuterCos;

uniform vec3 uRectPositions[16];
uniform vec3 uRectColors[16];
uniform vec3 uRectDirs[16];
uniform vec2 uRectSizes[16];
uniform int uRectCount;

// Shadow maps
uniform sampler2D uShadowMaps[4];
uniform mat4 uLightViewProj[4];
uniform int uCascadeCount;
uniform float uCascadeSplits[4];
uniform float uShadowBias;
uniform int uShadowPCFKernel;
uniform ivec2 uShadowMapSize[4];

uniform sampler2D uSpotShadowMap;
uniform mat4 uSpotLightVP;
uniform float uSpotShadowBias;
uniform int uUseSpotShadow;
#endheader

// --------------------------------------------------
// Main
// --------------------------------------------------
// ----------------- MAIN -----------------
void main(){
    // Base color
    vec4 baseColor = getMaterialColor(vUV, vTexIndex, uUseTextureArray);
    baseColor *= vInstanceColor;
    baseColor *= uVertexColor;

    // Alpha
    float alpha = baseColor.a;
    if(uUseAlphaMap == 1) {
        alpha *= sampleAlphaMap(vUV, vTexIndex, uUseTextureArray);
    }
    // Wenn uUseAlpha aktiv, multipliziere mit uAlphaFactor
    if(uUseAlpha == 1){
        alpha *= clamp(uAlphaFactor, 0.0, 1.0);
    }
    if (alpha < uAlphaThreshold) discard;

    // View vector
    vec3 V = normalize(uCameraPos - vWorldPos);

    // Normal
    vec3 N = sampleNormal(vUV, vTexIndex, uUseNormalArray);
    N = normalize(N);
    N = applyBump(N, V, vUV);

    // Albedo (linear)
    vec3 albedo = pow(baseColor.rgb, vec3(2.2));
    albedo = applyTintToAlbedo(albedo);

    // Lightmap
    if (uUseLight == 1 && uUseLightMap == 1) {
        vec3 light = sampleLightMap(vUV);
        albedo *= mix(vec3(1.0), light, clamp(uLightFactor, 0.0, 1.0));
    }

    // AO
    float ao = 1.0;
    if (uUseAmbientOcclusion == 1) {
        if (uUseAmbientOcclusionMap == 1) {
            ao = sampleAOMap(vUV, vTexIndex, uUseTextureArray);
        } else {
            ao = clamp(uAmbientOcclusionFactor, 0.0, 1.0); // fallback scalar
        }
        ao = mix(1.0, ao, clamp(uAmbientOcclusionFactor, 0.0, 1.0));
    }

    albedo *= uDiffuseFactor;

    // PBR params
    float metallic = sampleMetallicMap(vUV, vTexIndex, uUseTextureArray);
    float roughness = sampleRoughnessMap(vUV, vTexIndex, uUseTextureArray);


    // Shadows
    float sunShadow = calcCSMShadow(vWorldPos, uShadowMaps, uLightViewProj, uCascadeCount, uShadowBias, uShadowPCFKernel, uShadowMapSize);
    float spotShadow = calcSpotShadow(vWorldPos, uSpotShadowMap, uSpotLightVP, uSpotShadowBias, uShadowPCFKernel, uUseSpotShadow);

    vec3 color = vec3(0.0);

    // Lighting contributions
    color += computeSunLight(N, V, albedo, metallic, roughness, uSunDirection, uSunColor, uSunIntensity, sunShadow);
    color += computeAllPointLights(N, V, albedo, metallic, roughness, uPointCount, uPointPositions, uPointColors, uPointDirs, uPointParams, vWorldPos);
    color += uAmbientColor * uAmbientIntensity * ao * albedo;
    color += computeSpotLight(N, V, albedo, metallic, roughness, uSpotPosition, uSpotDirection, uSpotInnerCos, uSpotOuterCos, uSpotColor, uSpotIntensity, uSpotRange, vWorldPos) * spotShadow;

    // Rect lights
    for(int i=0;i<uRectCount;i++){
        vec3 L = normalize(uRectPositions[i] - vWorldPos);
        float NdotL = max(dot(N,L),0.0);
        vec3 H = normalize(V+L);
        vec3 F0 = mix(vec3(0.04), albedo, metallic);
        // apply specular factor/map
        float specScalar = sampleSpecular(vUV, vTexIndex, uUseTextureArray);
        F0 *= specScalar;
        float D = DistributionGGX(N,H,roughness);
        float G = GeometrySmith(N,V,L,roughness);
        vec3 F = fresnelSchlick(max(dot(H,V),0.0), F0);
        vec3 spec = (D*G*F)/max(4.0*max(dot(N,V),0.001)*NdotL,0.0001);
        vec3 kS = F;
        vec3 kD = (1.0-kS)*(1.0-metallic);
        color += (kD*albedo/3.14159265 + spec) * uRectColors[i] * NdotL;
    }

    // Tone map + gamma
    color = color/(color+vec3(1.0));
    color = pow(color, vec3(1.0/2.2));

    fragColor = vec4(color, alpha);
}