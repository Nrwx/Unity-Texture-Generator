#header
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUV;

out vec3 vWorldPos;
out vec2 vUV;

uniform mat4 uViewProj;
#endheader

void main() {
    vUV = aUV;
    vWorldPos = aPos;

    // Skybox position wird nur durch ViewProj transformiert (keine Translation)
    vec4 pos = uViewProj * vec4(aPos, 1.0);
    gl_Position = pos.xyww; // w -> depth trick für skybox
}
