#fragment
vec3 skyGradient(vec3 worldPos, vec3 topColor, vec3 bottomColor) {
    float t = worldPos.y * 0.5 + 0.5; // normalize -1..1 -> 0..1
    return mix(bottomColor, topColor, t);
}
#endfragment
