#fragment
vec3 skyClouds(vec2 uv, sampler2D tex, float time, float alpha, vec2 speed, vec2 scale) {
    vec2 uvMod = uv * scale + speed * time;
    vec3 cloudCol = texture(tex, uvMod).rgb;
    return cloudCol * alpha;
}
#endfragment
