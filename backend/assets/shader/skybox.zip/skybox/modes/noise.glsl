#fragment
vec3 skyNoise(vec2 uv, sampler2D tex) {
    vec3 noiseCol = texture(tex, uv).rgb;
    return (noiseCol - 0.5) * 0.1; // subtiler Effekt
}
#endfragment
