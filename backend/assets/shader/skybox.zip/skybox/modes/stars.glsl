#fragment
vec3 skyStars(vec2 uv, sampler2D tex, float time, float glow, vec2 speed) {
    vec2 uvMod = uv + speed * time;
    vec3 starCol = texture(tex, uvMod).rgb;
    float lum = pow(length(starCol), 2.0) * glow;
    return starCol * lum;
}
#endfragment
