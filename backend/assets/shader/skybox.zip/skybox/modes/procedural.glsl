#fragment
vec3 proceduralGradient(vec3 dir) {
    float t = dir.y * 0.5 + 0.5;
    return mix(uSkyBottomColor, uSkyTopColor, t);
}

vec3 proceduralClouds(vec3 dir) {
    vec2 uv = dir.xz * 0.5 + 0.5;
    uv += uTime * 0.01;
    vec3 cloudCol = texture(uCloudTex, uv).rgb;
    return cloudCol * 0.5;
}

vec3 proceduralStars(vec3 dir) {
    vec2 uv = dir.xy * 0.5 + 0.5;
    vec3 starCol = texture(uStarTex, uv).rgb;
    starCol = step(0.8, starCol) * starCol;
    return starCol;
}

vec3 skyboxProcedural(vec3 dir) {
    vec3 color = vec3(0.0);
    color += proceduralGradient(dir);
    color += proceduralClouds(dir);
    color += proceduralStars(dir);
    return color * uSkyTint * uSkyIntensity;
}
#endfragment
