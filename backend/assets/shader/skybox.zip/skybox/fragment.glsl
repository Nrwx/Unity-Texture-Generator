#header
in vec3 vWorldPos;
in vec2 vUV;

out vec4 fragColor;

// ----------------------------
// Skybox
// ----------------------------
uniform samplerCube uCubemap;
uniform int uSkyboxMode;
uniform int uUseSkyNoise;

uniform sampler2D uCloudTex;
uniform sampler2D uStarTex;

uniform sampler2D uSkyClouds;
uniform float uCloudAlpha;
uniform vec2 uCloudSpeed;
uniform vec2 uCloudScale;

uniform sampler2D uSkyStars;
uniform float uStarsGlow;
uniform vec2 uStarsSpeed;

uniform sampler2D uSkyNoise;

uniform vec3 uSkyTint;
uniform float uSkyIntensity;
uniform vec3 uSkyTopColor;
uniform vec3 uSkyBottomColor;

uniform float uTime;

#endheader
// ----------------------------
// Main
// ----------------------------
void main() {
    vec3 color = vec3(0.0);

    if (uSkyboxMode == 1) {
        color += texture(uCubemap, normalize(vWorldPos)).rgb;
    } else if (uSkyboxMode == 0) {
        color += skyboxProcedural(vWorldPos);
    }

    // Optional: Overlay 2D modules auf beiden Modi
    color += skyGradient(vWorldPos, uSkyTopColor, uSkyBottomColor);
    color = mix(
        color,
        skyClouds(vUV, uSkyClouds, uTime, uCloudAlpha, uCloudSpeed, uCloudScale),
        uCloudAlpha
    );
    color += skyStars(vUV, uSkyStars, uTime, uStarsGlow, uStarsSpeed);

    if (uUseSkyNoise == 1) {
        color += skyNoise(vUV, uSkyNoise);
    }

    // Final tint and intensity
    color *= uSkyTint * uSkyIntensity;

    fragColor = vec4(color, 1.0);
}
