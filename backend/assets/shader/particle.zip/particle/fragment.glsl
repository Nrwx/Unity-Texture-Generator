#header
in vec2 vUV;
in vec4 vColor;
in float vLife;

uniform sampler2D uTex;
uniform float uAlphaIn;
uniform float uAlphaOut;

out vec4 fragColor;
#endheader

void main() {
    vec4 particle = texture(uTex, vUV) * vColor;

    float alpha = 1.0;

    if (uAlphaIn > 0.0)
        alpha *= smoothstep(0.0, uAlphaIn, vLife);
    if (uAlphaOut > 0.0)
        alpha *= 1.0 - smoothstep(1.0 - uAlphaOut, 1.0, vLife);

    particle.a *= alpha;

    if (particle.a <= 0.001) discard;

    fragColor = particle; // ✅ FERTIG
}
