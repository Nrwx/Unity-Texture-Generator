#fragment
// alphaFade.glsl
float applyAlphaFade(float life, float alphaIn, float alphaOut) {
    float alpha = 1.0;
    if (alphaIn > 0.0) alpha *= smoothstep(0.0, alphaIn, life);
    if (alphaOut > 0.0) alpha *= 1.0 - smoothstep(1.0 - alphaOut, 1.0, life);
    return alpha;
}
#endfragment
