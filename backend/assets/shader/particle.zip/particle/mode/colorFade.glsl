#fragment
// applyColorFade.glsl
vec4 applyColorFade(vec4 color, float life, float alphaIn, float alphaOut) {
    float alpha = 1.0;
    if (alphaIn > 0.0)  alpha *= smoothstep(0.0, alphaIn, life);
    if (alphaOut > 0.0) alpha *= 1.0 - smoothstep(1.0 - alphaOut, 1.0, life);
    return vec4(color.rgb, color.a * alpha);
}
#endfragment
