import os
import json
import time
import fnmatch
from typing import Dict, Any, List, Tuple
import sys
import tempfile
import subprocess

from huggingface_hub import HfApi, hf_hub_download


def _now_ms():
    return int(time.time() * 1000)


def _resolve_save_dir(manifest, context):
    config = manifest.get("config", {})
    save_dir = config.get("saveDir") or "data"

    if os.path.isabs(save_dir):
        return os.path.abspath(save_dir)

    return os.path.abspath(os.path.join(context["pluginRoot"], save_dir))


def _resolve_token(manifest, context):
    return context.get("hfToken")


def _manifest_path(context):
    return context.get("manifestPath")


def _pause_path(context):
    return context.get("pausePath")


def _pause_requested(context):
    path = _pause_path(context)
    return bool(path and os.path.exists(path))


def _write_manifest(manifest, context):
    path = _manifest_path(context)
    if not path:
        return

    os.makedirs(os.path.dirname(path), exist_ok=True)

    last_error = None

    for attempt in range(20):
        tmp = f"{path}.{os.getpid()}.{attempt}.tmp"

        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(manifest, f, indent=2, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())

            os.replace(tmp, path)
            return

        except PermissionError as e:
            last_error = e
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass

            time.sleep(0.1 + (attempt * 0.05))

        except OSError as e:
            last_error = e
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass

            time.sleep(0.1 + (attempt * 0.05))

    raise last_error


def _as_list(value):
    if value is None:
        return None

    if isinstance(value, list):
        return value

    return [value]


def _matches_patterns(filename: str, allow_patterns, ignore_patterns) -> bool:
    allow_patterns = _as_list(allow_patterns)
    ignore_patterns = _as_list(ignore_patterns)

    filename = filename.replace("\\", "/")

    if allow_patterns:
        allowed = any(fnmatch.fnmatch(filename, pattern) for pattern in allow_patterns)
        if not allowed:
            return False

    if ignore_patterns:
        ignored = any(fnmatch.fnmatch(filename, pattern) for pattern in ignore_patterns)
        if ignored:
            return False

    return True


def _get_expected_files(
    repo_id: str,
    revision,
    token,
    allow_patterns,
    ignore_patterns
) -> Tuple[List[Dict[str, Any]], int]:
    api = HfApi()

    info = api.repo_info(
        repo_id=repo_id,
        revision=revision,
        repo_type="model",
        files_metadata=True,
        token=token
    )

    files = []

    for sibling in info.siblings or []:
        filename = getattr(sibling, "rfilename", None)
        size = getattr(sibling, "size", None)

        if not filename:
            continue

        filename = filename.replace("\\", "/")

        if not _matches_patterns(filename, allow_patterns, ignore_patterns):
            continue

        files.append({
            "path": filename,
            "size": int(size or 0),
            "blobId": getattr(sibling, "blob_id", None),
        })

    files.sort(key=lambda item: item["path"])

    expected_bytes = sum(item["size"] for item in files if item["size"] > 0)
    return files, expected_bytes

def _download_file_abortable(
    context,
    repo_id,
    filename,
    revision,
    token,
    save_dir,
):
    """
    Lädt eine Datei in einem Child-Prozess.

    Vorteil:
    - Bei Pause kann der Child-Prozess beendet werden.
    - Der Hauptprozess bleibt kontrollierbar.
    - Fortsetzen nutzt HF-Cache/Partial-Daten weiter.
    """
    fd, args_path = tempfile.mkstemp(prefix="hf_download_", suffix=".json")
    os.close(fd)

    args = {
        "repo_id": repo_id,
        "filename": filename,
        "revision": revision,
        "repo_type": "model",
        "token": token,
        "local_dir": save_dir,
    }

    with open(args_path, "w", encoding="utf-8") as f:
        json.dump(args, f)

    child_code = r"""
import json
import sys
from huggingface_hub import hf_hub_download

with open(sys.argv[1], "r", encoding="utf-8") as f:
    args = json.load(f)

hf_hub_download(
    repo_id=args["repo_id"],
    filename=args["filename"],
    revision=args.get("revision"),
    repo_type=args.get("repo_type") or "model",
    token=args.get("token"),
    local_dir=args["local_dir"],
    force_download=False,
)
"""

    creationflags = 0

    if os.name == "nt":
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)

    process = subprocess.Popen(
        [sys.executable, "-c", child_code, args_path],
        creationflags=creationflags
    )

    try:
        while process.poll() is None:
            if _pause_requested(context):
                process.terminate()

                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)

                return False

            time.sleep(0.5)

        if process.returncode != 0:
            raise RuntimeError(
                f"Download fehlgeschlagen für Datei '{filename}' "
                f"mit Exit-Code {process.returncode}"
            )

        return True

    finally:
        try:
            os.remove(args_path)
        except Exception:
            pass

def _scan_hf_partial_bytes(save_dir: str) -> int:
    partial_bytes = 0

    candidate_roots = [
        os.path.join(save_dir, ".cache"),
        os.path.join(save_dir, ".huggingface"),
    ]

    partial_suffixes = (
        ".incomplete",
        ".partial",
        ".tmp",
    )

    for root in candidate_roots:
        if not os.path.isdir(root):
            continue

        for dirpath, _, filenames in os.walk(root):
            for filename in filenames:
                path = os.path.join(dirpath, filename)

                try:
                    if filename.endswith(partial_suffixes):
                        partial_bytes += os.path.getsize(path)
                        continue

                    lower_path = path.lower().replace("\\", "/")
                    if "/download" in lower_path or "/blobs" in lower_path:
                        size = os.path.getsize(path)
                        if size > 1024 * 1024:
                            partial_bytes += size

                except OSError:
                    continue

    return partial_bytes


def _scan_local_files(save_dir: str, expected_files: List[Dict[str, Any]]):
    final_present_bytes = 0
    complete_files = []
    partial_files = []
    missing_files = []

    for item in expected_files:
        rel_path = item["path"]
        expected_size = int(item.get("size") or 0)
        local_path = os.path.join(save_dir, rel_path)

        if not os.path.exists(local_path):
            missing_files.append(rel_path)
            continue

        local_size = os.path.getsize(local_path)
        counted_size = min(local_size, expected_size) if expected_size else local_size
        final_present_bytes += counted_size

        if expected_size and local_size != expected_size:
            partial_files.append({
                "path": rel_path,
                "expected": expected_size,
                "actual": local_size,
            })
            continue

        complete_files.append(rel_path)

    partial_cache_bytes = _scan_hf_partial_bytes(save_dir)

    expected_total = sum(int(item.get("size") or 0) for item in expected_files)
    present_bytes = final_present_bytes + partial_cache_bytes

    if expected_total > 0:
        present_bytes = min(present_bytes, expected_total)

    return {
        "presentBytes": present_bytes,
        "finalPresentBytes": final_present_bytes,
        "partialCacheBytes": partial_cache_bytes,
        "completeFiles": complete_files,
        "partialFiles": partial_files,
        "missingFiles": missing_files,
        "isComplete": len(missing_files) == 0 and len(partial_files) == 0,
    }


def _update_download_status(
    manifest,
    context,
    save_dir,
    expected_files,
    expected_bytes,
    local_state,
    phase="install",
    message=None,
):
    manifest.setdefault("status", {})
    manifest.setdefault("paths", {})

    status = manifest["status"]

    present_bytes = int(local_state.get("presentBytes") or 0)
    progress = 0

    if expected_bytes > 0:
        progress = int(min(99, max(1, (present_bytes / expected_bytes) * 100)))

    is_complete = bool(local_state.get("isComplete"))
    is_active = not is_complete and phase not in ("done", "error", "skipped", "paused")

    status["xhr"] = is_active
    status["running"] = is_active
    status["paused"] = phase == "paused"
    status["pauseRequested"] = _pause_requested(context)
    status["installed"] = is_complete
    status["saved"] = is_complete
    status["skipped"] = False
    status["path"] = os.path.abspath(save_dir)
    status["error"] = None
    status["phase"] = phase
    status["progress"] = 100 if is_complete else progress
    status["message"] = message or "Downloadstatus geprüft."
    status["heartbeatAt"] = _now_ms()

    status["expectedBytes"] = int(expected_bytes or 0)
    status["presentBytes"] = present_bytes
    status["finalPresentBytes"] = int(local_state.get("finalPresentBytes") or 0)
    status["partialCacheBytes"] = int(local_state.get("partialCacheBytes") or 0)

    status["missingFiles"] = local_state.get("missingFiles", [])[:50]
    status["partialFiles"] = local_state.get("partialFiles", [])[:50]
    status["expectedFileCount"] = len(expected_files)
    status["completeFileCount"] = len(local_state.get("completeFiles", []))
    status["missingFileCount"] = len(local_state.get("missingFiles", []))
    status["partialFileCount"] = len(local_state.get("partialFiles", []))

    manifest["paths"]["data"] = os.path.abspath(save_dir)

    _write_manifest(manifest, context)
    return manifest


def _mark_paused(manifest, context, save_dir, expected_files, expected_bytes):
    local_state = _scan_local_files(save_dir, expected_files)

    manifest = _update_download_status(
        manifest,
        context,
        save_dir,
        expected_files,
        expected_bytes,
        local_state,
        phase="paused",
        message="Download pausiert. Installation kann später fortgesetzt werden."
    )

    status = manifest.setdefault("status", {})
    status["xhr"] = False
    status["running"] = False
    status["paused"] = True
    status["pauseRequested"] = True
    status["error"] = None
    status["finishedAt"] = _now_ms()

    _write_manifest(manifest, context)
    return manifest


def _finalize_success(manifest, context, save_dir, expected_files, expected_bytes):
    local_state = _scan_local_files(save_dir, expected_files)

    if not local_state["isComplete"]:
        manifest = _update_download_status(
            manifest,
            context,
            save_dir,
            expected_files,
            expected_bytes,
            local_state,
            phase=manifest.get("status", {}).get("phase") or "install",
            message="Download noch unvollständig."
        )

        missing_count = len(local_state["missingFiles"])
        partial_count = len(local_state["partialFiles"])

        raise RuntimeError(
            f"Download unvollständig: {missing_count} Dateien fehlen, "
            f"{partial_count} Dateien sind partiell."
        )

    manifest = _update_download_status(
        manifest,
        context,
        save_dir,
        expected_files,
        expected_bytes,
        local_state,
        phase="done",
        message="Plugin vollständig installiert."
    )

    status = manifest.setdefault("status", {})
    status["xhr"] = False
    status["running"] = False
    status["paused"] = False
    status["pauseRequested"] = False
    status["installed"] = True
    status["saved"] = True
    status["progress"] = 100
    status["error"] = None
    status["finishedAt"] = _now_ms()

    _write_manifest(manifest, context)
    return manifest


def _download_file_by_file(
    manifest,
    context,
    repo_id,
    revision,
    token,
    save_dir,
    expected_files,
    expected_bytes,
):
    status = manifest.setdefault("status", {})
    phase = "repair" if status.get("action") == "repair" else "install"

    for index, item in enumerate(expected_files):
        if _pause_requested(context):
            return _mark_paused(
                manifest,
                context,
                save_dir,
                expected_files,
                expected_bytes
            )

        filename = item["path"]
        expected_size = int(item.get("size") or 0)
        local_path = os.path.join(save_dir, filename)

        if expected_size and os.path.exists(local_path):
            try:
                if os.path.getsize(local_path) == expected_size:
                    continue
            except OSError:
                pass

        local_state = _scan_local_files(save_dir, expected_files)

        manifest = _update_download_status(
            manifest,
            context,
            save_dir,
            expected_files,
            expected_bytes,
            local_state,
            phase=phase,
            message=f"Lade Datei {index + 1}/{len(expected_files)}: {filename}"
        )

        completed = _download_file_abortable(
            context=context,
            repo_id=repo_id,
            filename=filename,
            revision=revision,
            token=token,
            save_dir=save_dir,
        )

        if not completed:
            return _mark_paused(
                manifest,
                context,
                save_dir,
                expected_files,
                expected_bytes
            )

        if _pause_requested(context):
            return _mark_paused(
                manifest,
                context,
                save_dir,
                expected_files,
                expected_bytes
            )

    return _finalize_success(
        manifest,
        context,
        save_dir,
        expected_files,
        expected_bytes
    )


def save(manifest, context):
    config = manifest.get("config", {})

    repo_id = config.get("repoId")
    if not repo_id:
        raise ValueError("repoId fehlt in manifest.config.repoId")

    save_dir = _resolve_save_dir(manifest, context)
    os.makedirs(save_dir, exist_ok=True)

    token = _resolve_token(manifest, context)
    revision = config.get("revision")
    allow_patterns = config.get("allowPatterns")
    ignore_patterns = config.get("ignorePatterns")

    expected_files, expected_bytes = _get_expected_files(
        repo_id=repo_id,
        revision=revision,
        token=token,
        allow_patterns=allow_patterns,
        ignore_patterns=ignore_patterns
    )

    phase = "repair" if manifest.get("status", {}).get("action") == "repair" else "install"

    local_state = _scan_local_files(save_dir, expected_files)

    manifest = _update_download_status(
        manifest,
        context,
        save_dir,
        expected_files,
        expected_bytes,
        local_state,
        phase=phase,
        message="Lokaler Downloadstand wurde geprüft."
    )

    if _pause_requested(context):
        return _mark_paused(
            manifest,
            context,
            save_dir,
            expected_files,
            expected_bytes
        )

    if local_state["isComplete"]:
        return _finalize_success(
            manifest,
            context,
            save_dir,
            expected_files,
            expected_bytes
        )

    return _download_file_by_file(
        manifest=manifest,
        context=context,
        repo_id=repo_id,
        revision=revision,
        token=token,
        save_dir=save_dir,
        expected_files=expected_files,
        expected_bytes=expected_bytes,
    )